# SVL\_QERROR<a name="r_SVL_QERROR"></a>

The SVL\_QERROR view is deprecated\.