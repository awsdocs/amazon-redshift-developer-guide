# REPLICATE function<a name="r_REPLICATE"></a>

Synonym for the REPEAT function\. 

See [REPEAT function](r_REPEAT.md)\. 