# Hash functions<a name="hash-functions"></a>

**Topics**
+ [CHECKSUM function](r_CHECKSUM.md)
+ [farmFingerprint64 function](r_FARMFINGERPRINT64.md)
+ [FUNC\_SHA1 function](FUNC_SHA1.md)
+ [FNV\_HASH function](r_FNV_HASH.md)
+ [MD5 function](r_MD5.md)
+ [SHA function](SHA.md)
+ [SHA1 function](SHA1.md)
+ [SHA2 function](SHA2.md)

A hash function is a mathematical function that converts a numerical input value into another value\.