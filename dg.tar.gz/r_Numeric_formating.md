# Numeric format strings<a name="r_Numeric_formating"></a>

Following, you can find a reference for numeric format strings\. 

The following format strings apply to functions such as TO\_NUMBER and TO\_CHAR\. For examples of formatting strings as numbers, see [TO\_NUMBER](r_TO_NUMBER.md)\. For examples of formatting numbers as strings, see [TO\_CHAR](r_TO_CHAR.md)\.

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_Numeric_formating.html)