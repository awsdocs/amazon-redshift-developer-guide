# STL\_SSHCLIENT\_ERROR<a name="r_STL_SSHCLIENT_ERROR"></a>

 Records all errors seen by the SSH client\. 

This view is visible to all users\. Superusers can see all rows; regular users can see only their own data\. For more information, see [Visibility of data in system tables and views](c_visibility-of-data.md)\.

## Table columns<a name="r_STL_SSHCLIENT_ERROR-table-columns"></a>

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_STL_SSHCLIENT_ERROR.html)