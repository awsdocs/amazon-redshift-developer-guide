# SUBSTR function<a name="r_SUBSTR"></a>

Synonym of the SUBSTRING function\. 

See [SUBSTRING function](r_SUBSTRING.md)\. 