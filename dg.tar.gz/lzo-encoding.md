# LZO encoding<a name="lzo-encoding"></a>

LZO encoding provides a very high compression ratio with good performance\. LZO encoding works especially well for CHAR and VARCHAR columns that store very long character strings\. They are especially good for free\-form text, such as product descriptions, user comments, or JSON strings\. 