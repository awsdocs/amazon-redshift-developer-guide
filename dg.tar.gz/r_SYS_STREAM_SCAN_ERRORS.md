# SYS\_STREAM\_SCAN\_ERRORS<a name="r_SYS_STREAM_SCAN_ERRORS"></a>

Records errors for records loaded via streaming ingestion\.

SYS\_STREAM\_SCAN\_ERRORS is visible only to the superuser\.

## Table columns<a name="r_SYS_STREAM_SCAN_ERRORS-table-rows"></a>

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_SYS_STREAM_SCAN_ERRORS.html)