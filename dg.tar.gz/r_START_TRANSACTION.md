# START TRANSACTION<a name="r_START_TRANSACTION"></a>

Synonym of the BEGIN function\. 

See [BEGIN](r_BEGIN.md)\. 