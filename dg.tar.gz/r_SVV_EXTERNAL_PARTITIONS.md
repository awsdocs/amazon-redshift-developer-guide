# SVV\_EXTERNAL\_PARTITIONS<a name="r_SVV_EXTERNAL_PARTITIONS"></a>

Use SVV\_EXTERNAL\_PARTITIONS to view details for partitions in external tables\. 

SVV\_EXTERNAL\_PARTITIONS is visible to all users\. Superusers can see all rows; regular users can see only metadata to which they have access\. For more information, see [CREATE EXTERNAL SCHEMA](r_CREATE_EXTERNAL_SCHEMA.md)\.

## Table columns<a name="r_SVV_EXTERNAL_PARTITIONS-table-columns"></a>

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_SVV_EXTERNAL_PARTITIONS.html)