# ST\_Perimeter2D<a name="ST_Perimeter2D-function"></a>

ST\_Perimeter2D is an alias for ST\_Perimeter\. For more information, see [ST\_Perimeter](ST_Perimeter-function.md)\. 