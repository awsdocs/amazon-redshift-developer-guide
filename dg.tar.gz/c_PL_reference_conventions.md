# PL/pgSQL reference conventions<a name="c_PL_reference_conventions"></a>

In this section, you can find the conventions that are used to write the syntax for the PL/pgSQL stored procedure language\. 

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/c_PL_reference_conventions.html)