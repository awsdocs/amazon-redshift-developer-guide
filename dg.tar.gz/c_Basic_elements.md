# Basic elements<a name="c_Basic_elements"></a>

**Topics**
+ [Names and identifiers](r_names.md)
+ [Literals](r_Literals.md)
+ [Nulls](r_Nulls.md)
+ [Data types](c_Supported_data_types.md)
+ [Collation sequences](c_collation_sequences.md)

This section covers the rules for working with database object names, literals, nulls, and data types\. 