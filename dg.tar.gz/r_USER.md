# USER<a name="r_USER"></a>

Synonym for CURRENT\_USER\. See [CURRENT\_USER](r_CURRENT_USER.md)\. 