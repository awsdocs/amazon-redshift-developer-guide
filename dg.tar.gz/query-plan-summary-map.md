# Mapping the query plan to the query summary<a name="query-plan-summary-map"></a>

It helps to map the operations from the query plan to the steps \(identified by the label field values\) in the query summary to get further details:

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/query-plan-summary-map.html)