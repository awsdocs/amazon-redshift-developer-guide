# CATEGORY table<a name="r_categorytable"></a>

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_categorytable.html)