# FUNC\_SHA1 function<a name="FUNC_SHA1"></a>

Synonym of SHA1 function\. 

See [SHA1 function](SHA1.md)\. 