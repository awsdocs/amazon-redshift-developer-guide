# SQL reference conventions<a name="c_SQL_reference_conventions"></a>

This section explains the conventions that are used to write the syntax for the SQL expressions, commands, and functions described in the SQL reference section\. 

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/c_SQL_reference_conventions.html)