# SVV\_TABLES<a name="r_SVV_TABLES"></a>

Use SVV\_TABLES to view tables in local and external catalogs\.

SVV\_TABLES is visible to all users\. Superusers can see all rows; regular users can see only metadata to which they have access\. 

## Table columns<a name="r_SVV_TABLES-table-columns"></a>

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_SVV_TABLES.html)