# ST\_Length2D<a name="ST_Length2D-function"></a>

ST\_Length2D is an alias for ST\_Length\. For more information, see [ST\_Length](ST_Length-function.md)\. 