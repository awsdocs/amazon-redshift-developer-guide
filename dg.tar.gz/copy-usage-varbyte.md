# Loading a column of the VARBYTE data type<a name="copy-usage-varbyte"></a>

You can load data from a file in CSV format\. The data is loaded from a file in hexadecimal representation of the VARBYTE data\. You can't load VARBYTE data with the `FIXEDWIDTH` option\. The `ADDQUOTES` or `REMOVEQUOTES` option of COPY is not supported\. A VARBYTE column can't be used as a partition column\.  