# LISTING table<a name="r_listingtable"></a>

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_listingtable.html)