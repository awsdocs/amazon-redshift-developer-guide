# System permissions for RBAC<a name="r_roles-system-privileges"></a>

Following is a list of system permissions that you can grant to or revoke from a role\.

[\[See the AWS documentation website for more details\]](http://docs.aws.amazon.com/redshift/latest/dg/r_roles-system-privileges.html)