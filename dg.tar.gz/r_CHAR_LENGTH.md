# CHAR\_LENGTH function<a name="r_CHAR_LENGTH"></a>

Synonym of the LEN function\. 

See [LEN function](r_LEN.md)\. 